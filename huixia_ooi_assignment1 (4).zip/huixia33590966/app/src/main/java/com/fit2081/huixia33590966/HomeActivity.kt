package com.fit2081.huixia33590966

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.huixia33590966.ui.theme.Huixia33590966Theme


/**
 * Loads the Food Quality Score for a given user based on their UserID.
 * The data is retrieved from the CSV file stored under assets.
 *
 * @param context The application context used to access assets.
 * @param userId The unique ID of the user whose score is being retrieved.
 * @return The food quality score as a Double. Returns 0.0 if the user is not found or data is invalid.
 */
fun loadFoodQualityScore(context: Context, userId: String): Double {
    val inputStream = context.assets.open("user_data.csv")
    val lines = inputStream.bufferedReader().readLines()
    // Skip header line
    lines.drop(1).forEach { line ->
        val tokens = line.split(",")
        if (tokens.size >= 5) { // Ensure there are enough columns
            val csvUserId = tokens[1].trim()  // second column is User_ID
            if (csvUserId == userId) {
                val sex = tokens[2].trim()      // third column is Sex

                // Return the corresponding Food Quality Score based on user's sex
                return if (sex.equals("Male", ignoreCase = true)) {
                    tokens[3].trim().toDoubleOrNull() ?: 0.0
                } else {
                    tokens[4].trim().toDoubleOrNull() ?: 0.0
                }
            }
        }
    }
    return 0.0
}

/**
 * Home screen activity displaying the user's food quality score.
 */
class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Retrieve User ID from SharedPreferences
        val sharedPreferences = getSharedPreferences("NutriTrackPrefs", MODE_PRIVATE)
        val userId = sharedPreferences.getString("USER_ID", "Unknown ID") ?: "Unknown ID"

        setContent {
            Huixia33590966Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { MyBottomNavBar() }
                ) { innerPadding ->
                    // Retrieve the current Compose context
                    val context = LocalContext.current

                    // Load the score once (using remember for performance)
                    val score = remember {
                        com.fit2081.huixia33590966.loadFoodQualityScore(
                            context,
                            userId
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        GreetingSection(userId) // Displays greeting message with UserID
                        Spacer(modifier = Modifier.height(4.dp))
                        EditSection() // Section to edit food intake questionnaire
                        Spacer(modifier = Modifier.height(4.dp))
                        FoodImageSection()
                        Spacer(modifier = Modifier.height(4.dp))
                        // Call MyScoreSection to display the score
                        MyScoreSection(score = score)
                        Spacer(modifier = Modifier.height(4.dp))
                        FoodQualityInfoSection()
                    }
                }
            }
        }
    }
}

/**
 * Composable function to display a greeting message with the user's ID.
 */
@Composable
fun GreetingSection(userId: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        // First line: "Hello,"
        Text(
            text = "Hello,",
            fontSize = 18.sp,
            color = Color.Gray
        )
        // Second line: "user {ID}"
        Text(
            text = "User $userId",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Composable function displaying an editable section for the food intake questionnaire.
 */
@Composable
fun EditSection() {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "You've already filled in your Food Intake Questionnaire, but you can change details here:",
            fontSize = 16.sp,
            color = Color.Black,
            modifier = Modifier.weight(1f)
        )
        Button(
            onClick = {
                val intent = Intent(context, QuestionnaireActivity::class.java)
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7)),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.height(40.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Edit", fontSize = 14.sp)
        }
    }
}

/**
 * Composable function displaying an image related to food quality.
 */
@Composable
fun FoodImageSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.food_plate), // Make sure this resource exists
            contentDescription = "Food Plate",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )
    }
}

/**
 * Composable function displaying the user's food quality score.
 */
@Composable
fun MyScoreSection(score: Double) {
    val context = LocalContext.current  // Get the context for launching an activity

    Column(modifier = Modifier.padding(16.dp)) {
        // Row for "My Score" on the left and "See all scores" on the right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "My Score",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            // Make "See all scores >" clickable
            Text(
                text = "See all scores >",
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier.clickable {
                    val intent = Intent(context, InsightActivity::class.java)
                    context.startActivity(intent)  // Start the new activity
                }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Row for the arrow image, description, and numeric score
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.arrow_up), // Your arrow image resource
                contentDescription = "Arrow Upward",
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Your Food Quality score",
                fontSize = 16.sp,
                color = Color.Black
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "$score/100",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32) // Green color
            )
        }
    }
}

/**
 * Composable function explaining the Food Quality Score.
 */
@Composable
fun FoodQualityInfoSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text(
            text = "What is the Food Quality Score?",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Your Food Quality Score provides a snapshot of how well your eating patterns align with established food guidelines, helping you identify both strengths and opportunities for improvement in your diet.",
            fontSize = 14.sp,
            color = Color.DarkGray,
            lineHeight = 20.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "This personalized measurement considers various food groups including vegetables, fruits, whole grains, and proteins to give you practical insights for making healthier food choices.",
            fontSize = 14.sp,
            color = Color.DarkGray,
            lineHeight = 20.sp
        )
    }
}


@Composable
fun MyBottomNavBar() {
    val context = LocalContext.current

    NavigationBar {
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.home_icon),
                        contentDescription = "Home",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Home", fontSize = 12.sp)
                }
            },
            selected = true,
            onClick = {
                // val intent = Intent(context, InsightActivity::class.java)
                //context.startActivity(intent)
            }
        )
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.insights_icon),
                        contentDescription = "Insights",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Insights", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = {
                val intent = Intent(context, InsightActivity::class.java)
                context.startActivity(intent)
            }
        )

        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.nutricoach_icon),
                        contentDescription = "NutriCoach",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("NutriCoach", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = { /* Navigate to NutriCoach */ }
        )
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.settings_icon),
                        contentDescription = "Settings",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Settings", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = { /* Navigate to Settings */ }
        )
    }
}

