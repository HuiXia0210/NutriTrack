package com.fit2081.huixia33590966

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.huixia33590966.ui.theme.Huixia33590966Theme
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import kotlin.collections.component1
import kotlin.collections.component2
import kotlin.collections.iterator

/**
 * Activity to display user insights.
 * Loads food score and presents them with progress bars.
 */
class InsightActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Ensures UI elements extend to system bars
        setContent {
            Huixia33590966Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { MyNavBar(this) }
                ) { innerPadding ->
                    Column(modifier = Modifier.padding(innerPadding)) {
                        InsightsScreen()
                    }
                }
            }
        }
    }
}

/**
 * Composable function that displays the Insights screen.
 * Fetches user food scores and renders them using progress bars.
 */
@Composable
fun InsightsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE)
    val userId = sharedPreferences.getString("USER_ID", null)

    Log.d("InsightsScreen", "📌 Retrieved USER_ID: $userId")

    // State for holding the food score map
    val foodScore by produceState(initialValue = emptyMap<String, Float>(), userId) {
        value = userId?.let { getUserFoodScore(context, it) } ?: emptyMap()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),  // Enables scrolling
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Insights: Food Score", style = MaterialTheme.typography.headlineSmall)

        if (foodScore.isNotEmpty()) {
            // Display each category using a progress bar
            foodScore.forEach { (label, score) ->
                val maxScore = when (label) {
                    "water", "alcohol", "grains", "wholeGrains","saturatedFat", "unsaturatedFat" -> 5
                    "totalScore" -> 100
                    else -> 10
                }
                ScoreSlider(label.replaceFirstChar { it.uppercase() }, score, maxScore)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Button to share food score with others
            Button(
                onClick = {
                    val shareMessage = buildShareMessage(foodScore)
                    shareText(context, shareMessage)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share with someone")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Button to improve diet (future navigation to NutriCoach screen)
            Button(
                onClick = { /* Navigate to NutriCoach */ },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.improve_diet_icon),
                        contentDescription = "Improve diet",
                        modifier = Modifier.size(24.dp),
                        colorFilter = ColorFilter.tint(Color.White)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Improve my diet!")
                }
            }
        } else {
            Text("No data available", color = Color.Red)
        }
    }
}

/**
 * Builds the share message containing the user's food score.
 */
fun buildShareMessage(foodScore: Map<String, Float>): String {
    val totalScore = foodScore["totalScore"]?.toInt() ?: 0
    return "Hi, I just got a HEIFA score of $totalScore! 🎉 How about you?"
}

/**
 * Shares the provided message using an implicit intent.
 */
fun shareText(context: Context, message: String) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
    }
    context.startActivity(Intent.createChooser(shareIntent, "Share your HEIFA score via"))
}

@Composable
fun MyNavBar(context: Context) {
    NavigationBar {
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.home_icon),
                        contentDescription = "Home",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Home", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = { val intent = Intent(context, HomeActivity::class.java)
                context.startActivity(intent) }
        )
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.insights_icon),
                        contentDescription = "Insights",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Insights", fontSize = 12.sp)
                }
            },
            selected = true,
            onClick = { /* Stay on Insights */ }
        )
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.nutricoach_icon),
                        contentDescription = "NutriCoach",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("NutriCoach", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = { /* Navigate to NutriCoach */ }
        )
        NavigationBarItem(
            icon = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.settings_icon),
                        contentDescription = "Settings",
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Settings", fontSize = 12.sp)
                }
            },
            selected = false,
            onClick = { /* Navigate to Settings */ }
        )
    }
}

/**
 * Retrieves the user's food score data from the CSV file.
 * @return A map containing category names as keys and scores as values.
 */
fun getUserFoodScore(context: Context, userId: String): Map<String, Float> {
    return try {
        val inputStream = context.assets.open("user_data.csv")
        val reader = BufferedReader(InputStreamReader(inputStream))

        var result: Map<String, Float>? = null
        reader.useLines { lines ->
            val iterator = lines.iterator()
            if (!iterator.hasNext()) return@useLines // No headers/data

            iterator.next() // Skip header row
            for (line in iterator) {
                val row = line.split(",")
                if (row.size > 57 && row[1] == userId) {  // Ensure correct data size & match User ID
                    val sex = row[2]
                    result = mapOf(
                        "disrectionary" to row [if(sex == "Male") 5 else 6].toFloat(),
                        "vegetables" to row[if (sex == "Male") 8 else 9].toFloat(),
                        "fruits" to row[if (sex == "Male") 19 else 20].toFloat(),
                        "grains" to row[if (sex == "Male") 29 else 30].toFloat(),
                        "wholeGrains" to row[if (sex == "Male") 33 else 34].toFloat(),
                        "meat" to row[if (sex == "Male") 36 else 37].toFloat(),
                        "dairy" to row[if (sex == "Male") 40 else 41].toFloat(),
                        "sodium" to row[if (sex == "Male") 43 else 44].toFloat(),
                        "alcohol" to row[if (sex == "Male") 46 else 47].toFloat(),
                        "water" to row[if (sex == "Male") 49 else 50].toFloat(),
                        "sugar" to row[if (sex == "Male") 54 else 55].toFloat(),
                        "saturatedFat" to row[if (sex == "Male") 57 else 58].toFloat(),
                        "unsaturatedFat" to row[if (sex == "Male") 60 else 61].toFloat(),
                        "totalScore" to row[if (sex == "Male") 3 else 4].toFloat()
                    )
                    break
                }
            }
        }
        result ?: emptyMap()
    } catch (e: IOException) {
        Log.e("CSVLoader", "Error loading CSV: ${e.message}")
        emptyMap()
    } catch (e: Exception) {
        Log.e("CSVLoader", "Unexpected error: ${e.message}")
        emptyMap()
    }
}

/**
 * Displays a horizontal progress bar (slider) representing a food score.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScoreSlider(label: String, score: Float, maxScore: Int) {
    Column(modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, modifier = Modifier.weight(1f))
            Text(
                String.format("%.2f/%d", score, maxScore),
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.End
            )
        }

        Box(
            modifier = Modifier.fillMaxWidth().height(24.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            var actualWidth by remember { mutableStateOf(0f) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .onSizeChanged { actualWidth = it.width.toFloat() } // Capture actual width
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Background track
                    drawRoundRect(
                        color = Color(0xFFBA68C8),
                        size = size,
                        cornerRadius = CornerRadius(50f, 50f)
                    )

                    // Tick marks
                    val tickCount = 10
                    val tickSpacing = size.width / tickCount
                    for (i in 0..tickCount) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.7f),
                            radius = 3f,
                            center = Offset(i * tickSpacing, size.height / 2)
                        )
                    }
                }

                // Filled progress track
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val filledWidth = (score / maxScore) * actualWidth
                    drawRoundRect(
                        color = Color(0xFF800080),
                        size = Size(filledWidth, size.height),
                        cornerRadius = CornerRadius(50f, 50f)
                    )
                }
            }

            // Thumb (circle marker)
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = ((score / maxScore) * actualWidth).toInt() - 10, // Adjust for center alignment
                            y = 0
                        )
                    }
                    .size(20.dp)
                    .background(Color.White, shape = CircleShape)
                    .border(2.dp, Color(0xFF800080), CircleShape)
            )
        }
    }
}




