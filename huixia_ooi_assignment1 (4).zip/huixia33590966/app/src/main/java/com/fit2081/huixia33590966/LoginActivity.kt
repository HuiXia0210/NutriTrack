package com.fit2081.huixia33590966

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.huixia33590966.ui.theme.Huixia33590966Theme
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.sequences.forEach


/**
 * Function to load User ID & Phone Number from CSV file
 *
 * @param context The context used to access assets.
 * @param fileName The name of the CSV file
 * @return A Pair consisting of a sorted list of user IDs and a mapping of user IDs to phone numbers.
 */
fun loadCsvData(context: Context, fileName: String): Pair<List<String>, Map<String, String>> {
    val userIds: MutableList<String> = mutableListOf()
    val phoneNumbers: MutableMap<String, String> = mutableMapOf()

    try {
        val inputStream = context.assets.open(fileName)
        val reader = BufferedReader(InputStreamReader(inputStream))

        // Read each line from the CSV, skipping the headers
        reader.useLines { lines ->
            lines.drop(1).forEach { line ->
                val values = line.split(",").map { it.trim() }
                if (values.size >= 2) {
                    val userId = values[1] // Second column is UserID
                    val phoneNumber = values[0] // First column is PhoneNumber
                    userIds.add(userId)
                    phoneNumbers[userId] = phoneNumber
                }
            }
        }
        // Sort UserIDs numerically
        userIds.sortBy { it.toIntOrNull() ?: Int.MAX_VALUE }
        Log.d("CSVLoader", "Loaded ${userIds.size} user IDs.")
    } catch (e: Exception) {
        Log.e("CSVLoader", "Error loading CSV: ${e.message}")
    }
    return userIds to phoneNumbers
}

/**
 * Login Activity - The entry point for user authentication.
 */
class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen()
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen() {
    val context = LocalContext.current
    val (userIds, phoneNumbers) = loadCsvData(context, "user_data.csv")

    // UI State Variables
    var selectedUserId by remember { mutableStateOf("") }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var phoneNumber by remember { mutableStateOf("") }
    var isPhoneValid by remember { mutableStateOf(true) }
    var isUserValid by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf("") }  // Holds error message

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))
        Text(text = "Log in", fontSize = 24.sp, style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(20.dp))

        //Text(text = "My ID (Provided by your Clinician)", fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))

        // User ID Dropdown Selection
        ExposedDropdownMenuBox(
            expanded = dropdownExpanded,
            onExpandedChange = { dropdownExpanded = it }
        ) {
            OutlinedTextField(
                value = if (selectedUserId.isEmpty()) "Please select your ID" else selectedUserId,
                onValueChange = {},
                readOnly = true,
                label = { Text("My ID (Provided by your Clinician)") },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) }
            )

            ExposedDropdownMenu(
                expanded = dropdownExpanded,
                onDismissRequest = { dropdownExpanded = false }
            ) {
                userIds.forEach { id ->
                    DropdownMenuItem(
                        text = { Text(id) },
                        onClick = {
                            selectedUserId = id
                            phoneNumber = ""  // Reset phone number when new ID is selected
                            isUserValid = true  // Reset validation
                            dropdownExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Phone Number Input Field
        OutlinedTextField(
            value = phoneNumber,
            onValueChange = {
                phoneNumber = it
                isPhoneValid = it.length in 8..15 //Validate phone number length
                isUserValid = true // Reset validation
            },
            isError = !isPhoneValid || !isUserValid,
            label = { Text("Phone number") },  // Stays above the field
            placeholder = { Text("Enter your number") },  // Appears inside when empty
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Show Error Message if login fails
        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = Color.Red,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        Text(
            text = "This app is only for pre-registered users. Please have your ID and phone number handy before continuing.",
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Continue Button
        Button(
            onClick = {
                if (selectedUserId.isNotEmpty() && phoneNumber.isNotEmpty()) {
                    val registeredPhone = phoneNumbers[selectedUserId]
                    if (registeredPhone == phoneNumber) {
                        //  Save USER_ID in SharedPreferences
                        val sharedPref = context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE)
                        with(sharedPref.edit()) {
                            putString("USER_ID", selectedUserId)
                            apply()
                        }

                        // Navigate to Questionnaire Activity
                        val intent = Intent(context, QuestionnaireActivity::class.java).apply {
                            putExtra("USER_ID", selectedUserId)
                        }
                        context.startActivity(intent)

                        // Clear error message after successful login
                        errorMessage = ""
                    } else {
                        // Invalid phone number
                        errorMessage = "Invalid ID or phone number."
                        isPhoneValid = false
                    }
                } else {
                    // User ID or phone number is empty
                    errorMessage = "Invalid ID or phone number."
                    isUserValid = false
                    isPhoneValid = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Text(text = "Continue", fontSize = 16.sp)
        }
    }
}