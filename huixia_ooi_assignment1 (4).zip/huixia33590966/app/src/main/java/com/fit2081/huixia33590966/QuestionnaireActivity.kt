package com.fit2081.huixia33590966

import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.huixia33590966.ui.theme.Huixia33590966Theme
import java.util.Calendar
import kotlin.collections.set

/**
 * Retrieves the currently logged-in UserID from SharedPreferences.
 *
 * This function fetches the user ID from the shared preferences to personalize the questionnaire data storage.
 * If no user ID is found, a default value is returned.
 *
 * @param context The application context.
 * @return The stored userID, or "defaultUserId" if not found.
 */
fun getCurrentUserId(context: Context): String {
    val sharedPreferences = context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE)
    return sharedPreferences.getString("USER_ID", "defaultUserId") ?: "defaultUserId"
}

/**
 * Activity representing the Food Intake Questionnaire.
 * Users select food categories, a persona, and input meal timings.
 *
 * The data entered is stored in SharedPreferences for future retrieval.
 */

class QuestionnaireActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Retrieve the currently logged-in userID
        val currentUserId =
            com.fit2081.huixia33590966.getCurrentUserId(this)
        setContent {
            MaterialTheme {
                Scaffold(
                    topBar = { MyTopAppBar() } // Displays a top app bar
                ) { paddingValues ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .verticalScroll(rememberScrollState()) // Allows scrolling
                    ) {
                        // Section: Food category selection
                        FoodCategoryCheckboxes(currentUserId)
                        Spacer(modifier = Modifier.height(2.dp))
                        // Section: Persona selection
                        PersonaSelectionScreen()
                        Spacer(modifier = Modifier.height(2.dp))
                        // Section: Dropdown menu for persona selection
                        PersonaDropdownMenu(currentUserId)
                        Spacer(modifier = Modifier.height(2.dp))
                        // Section: Time selection for meal and sleep habits
                        TimeSelectionSection(currentUserId)
                        // Save button to store user input in SharedPreferences
                        SaveButton()
                    }
                }
            }
        }
    }
}

/**
 * A top app bar with a back button for navigation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTopAppBar() {
    val context = LocalContext.current
    //val onBackPressedDispatcher =
        //LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            titleContentColor = MaterialTheme.colorScheme.primary,
        ),
        title = {
            Text(
                "Food Intake Questionnaire",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        navigationIcon = {
            IconButton(onClick = {
                val intent = Intent(context, LoginActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT) // Prevents creating a new instance
                context.startActivity(intent)// Start LoginActivity without clearing login data
            }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back"
                )
            }
        }
    )
}

/**
 * Displays a list of food categories as checkboxes.
 * Users can select multiple food categories, which are saved to SharedPreferences.
 *
 * @param currentUserId The ID of the user to ensure personalized data storage.
 */
@Composable
fun FoodCategoryCheckboxes(currentUserId: String) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE) }
    val editor = remember { sharedPreferences.edit() }

    // Define the list of available food categories
    val foodCategories = listOf("Fruits", "Vegetables", "Grains", "Red Meat", "Seafood", "Poultry", "Fish", "Eggs", "Nuts/Seeds")

    // Maintain a state map to track selected checkboxes
    val checkedState = remember {
        mutableStateMapOf<String, Boolean>().apply {
            foodCategories.forEach { category ->
                // Use a unique key per user and category
                this[category] = sharedPreferences.getBoolean("${currentUserId}_$category", false)
            }
        }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Text("Tick all the food categories you can eat", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))

        // Arrange checkboxes in rows with 3 items per row for better UI presentation
        foodCategories.chunked(3).forEach { rowItems ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                rowItems.forEach { category ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Checkbox(
                            checked = checkedState[category] ?: false,
                            onCheckedChange = { isChecked ->
                                checkedState[category] = isChecked
                                // Save checkbox state using a unique key for each user
                                editor.putBoolean("${currentUserId}_$category", isChecked).apply()
                            }
                        )
                        Text(text = category, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

/**
 * Allows users to select their persona type from six predefined categories.
 * Displays a brief description of each persona and enables selection.
 */
@Composable
fun PersonaSelectionScreen() {
    var selectedPersona by remember { mutableStateOf<Triple<String, String, Int>?>(null) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Your Persona",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp)
        )
        Text(
            text = "People can be broadly classified into 6 different types based on their eating preferences. " +
                    "Click on each button below to find out the different types, and select the type that best fits you!",
            fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp)
        )
        val personas = listOf(
            Triple("Health Devotee", "I’m passionate about healthy eating & health plays a big part in my life. I use social media to follow active lifestyle personalities or get new recipes/exercise ideas. I may even buy superfoods or follow a particular type of diet. I like to think I am super healthy.", R.drawable.persona_1),
            Triple("Mindful Eater", "I’m health-conscious and being healthy and eating healthy is important to me. Although health means different things to different people, I make conscious lifestyle decisions about eating based on what I believe healthy means. I look for new recipes and healthy eating information on social media.", R.drawable.persona_2),
            Triple("Wellness Striver", "I aspire to be healthy (but struggle sometimes). Healthy eating is hard work! I’ve tried to improve my diet, but always find things that make it difficult to stick with the changes. Sometimes I notice recipe ideas or healthy eating hacks, and if it seems easy enough, I’ll give it a go.", R.drawable.persona_3),
            Triple("Balance Seeker", "I try and live a balanced lifestyle, and I think that all foods are okay in moderation. I shouldn’t have to feel guilty about eating a piece of cake now and again. I get all sorts of inspiration from social media like finding out about new restaurants, fun recipes and sometimes healthy eating tips.", R.drawable.persona_4),
            Triple("Health Procrastinator", "I’m contemplating healthy eating but it’s not a priority for me right now. I know the basics about what it means to be healthy, but it doesn’t seem relevant to me right now. I have taken a few steps to be healthier but I am not motivated to make it a high priority because I have too many other things going on in my life.", R.drawable.persona_5),
            Triple("Food Carefree", "I’m not bothered about healthy eating. I don’t really see the point and I don’t think about it. I don’t really notice healthy eating tips or recipes and I don’t care what I eat.", R.drawable.persona_6)
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (row in personas.chunked(3)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (name, description, imageRes) ->
                        Button(
                            onClick = { selectedPersona = Triple(name, description, imageRes) },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8000FF)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = name,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Visible,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
        selectedPersona?.let { (personaName, description, imageRes) ->
            PersonaModal(
                personaName = personaName,
                description = description,
                imageRes = imageRes,
                onDismiss = { selectedPersona = null }
            )
        }
    }
}

/**
 * Displays a modal dialog with detailed information about a selected persona.
 *
 * @param personaName The name of the selected persona.
 * @param description The description of the selected persona.
 * @param imageRes The resource ID of the persona's image.
 * @param onDismiss Callback function triggered when the modal is dismissed.
 */
@Composable
fun PersonaModal(personaName: String, description: String, imageRes: Int, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = "$personaName Image",
                    modifier = Modifier
                        .size(100.dp)
                        .padding(bottom = 8.dp)
                )
                Text(
                    text = personaName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(text = description, textAlign = TextAlign.Center)
            }
        },
        confirmButton = {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Button(onClick = onDismiss) {
                    Text("Dismiss")
                }
            }
        }
    )
}

/**
 * PersonaDropdownMenu displays a dropdown menu allowing users to select their health persona.
 * The selected persona is saved in SharedPreferences for persistence.
 *
 * @param currentUserId Unique identifier for the current user, used for storing persona selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonaDropdownMenu(currentUserId: String) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE) }
    val editor = remember { sharedPreferences.edit() }

    // Controls dropdown expansion state
    var expanded by remember { mutableStateOf(false) }

    // Retrieves the previously selected persona from SharedPreferences
    var selectedPersona by remember {
        mutableStateOf(sharedPreferences.getString("${currentUserId}_selectedPersona", "") ?: "")
    }

    // List of six persona options
    val personaOptions = listOf("Health Devotee", "Mindful Eater", "Wellness Striver", "Balance Seeker", "Health Procrastinator", "Food Carefree")
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        Text("Which persona best fits you?", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 4.dp))
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(
                value = selectedPersona.ifEmpty { "Select option" },
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )

            // Dropdown menu with persona options
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                personaOptions.forEach { name ->
                    DropdownMenuItem(
                        text = { Text(name) },
                        onClick = {
                            selectedPersona = name
                            editor.putString("${currentUserId}_selectedPersona", name).apply()
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

/**
 * TimeSelectionSection displays a section for selecting and storing user timings.
 *
 * @param currentUserId Unique identifier for the current user, used for storing time preferences.
 */
@Composable
fun TimeSelectionSection(currentUserId: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Timings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

        // Three time selection fields
        TimePickerRow("What time of day approx. do you normally eat your biggest meal?", "biggest_meal_time", currentUserId)
        TimePickerRow("What time of day approx. do you go to sleep at night?", "bedtime", currentUserId)
        TimePickerRow("What time of day approx. do you wake up in the morning?", "wake_up_time", currentUserId)
    }
}

/**
 * TimePickerRow displays a row containing a question and a time picker.
 * The selected time is stored in SharedPreferences.
 *
 * @param question The question prompting the user to select a time.
 * @param key Key for storing the selected time in SharedPreferences.
 * @param currentUserId Unique identifier for the current user.
 */
@Composable
fun TimePickerRow(question: String, key: String, currentUserId: String) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("NutriTrackPrefs", Context.MODE_PRIVATE) }
    val editor = remember { sharedPreferences.edit() }

    // Retrieves the stored time from SharedPreferences
    var time by remember { mutableStateOf(sharedPreferences.getString("${currentUserId}_$key", "00:00") ?: "00:00") }
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = question, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(end = 8.dp))
        OutlinedTextField(
            value = time,
            onValueChange = {},
            readOnly = true,
            trailingIcon = {
                IconButton(onClick = {
                    showTimePicker(context) { selectedTime ->
                        time = selectedTime
                        editor.putString("${currentUserId}_$key", selectedTime).apply()
                    }
                }) {
                    Text("🕑", fontSize = 18.sp)
                }
            },
            modifier = Modifier.width(120.dp),
            singleLine = true
        )
    }
}

/**
 * showTimePicker displays a time picker dialog for selecting a time.
 *
 * @param context The context used to display the dialog.
 * @param onTimeSelected Callback function that receives the selected time in HH:mm format.
 */
fun showTimePicker(context: Context, onTimeSelected: (String) -> Unit) {
    val calendar = Calendar.getInstance()
    val timePicker = TimePickerDialog(
        context,
        { _, hourOfDay, minute ->
            val formattedTime = String.format("%02d:%02d", hourOfDay, minute)
            onTimeSelected(formattedTime)
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE),
        true
    )
    timePicker.show()
}

/**
 * Saves user selections and navigates to the home screen.
 */
@Composable
fun SaveButton() {
    val context = LocalContext.current
    Button(
        onClick = {
            val intent = Intent(context, HomeActivity::class.java)
            context.startActivity(intent)
        },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8000FF)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .height(48.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.icon_save), // Replace with your actual image resource
            contentDescription = "Save",
            modifier = Modifier.size(24.dp),
            colorFilter = ColorFilter.tint(Color.White)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text("Save", color = Color.White)
    }
}